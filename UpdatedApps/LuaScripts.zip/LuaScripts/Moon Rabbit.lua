------------
--Lunarine--
------------
--By	  --
--CKbackup--
------------

wait(2)

player = game.Players.LocalPlayer
chara = player.Character
debby = game.Debris
local Mouse = player:GetMouse()

--Outfit and Weapons--
New = function(Object, Parent, Name, Data)
	local Object = Instance.new(Object)
	for Index, Value in pairs(Data or {}) do
		Object[Index] = Value
	end
	Object.Parent = Parent
	Object.Name = Name
	return Object
end
	
LeftArm = New("Model",chara,"LeftArm",{})
MainPart = New("Part",LeftArm,"MainPart",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(1, 2.00000024, 1),CFrame = CFrame.new(4.5, 3.00005722, -4.50000048, -1, 0, 0, 0, 1.00001287, 0, 0, 0, -1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",MainPart,"Weld",{Part0 = MainPart,Part1 = chara["Left Arm"],C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1.00000429, 0, 0, 0, -1.00000429),C1 = CFrame.new(0, 7.62939453e-006, 1.23977661e-005, 1, 0, 0, 0, 1.00000429, 0, 0, 0, 1.00000429),})
Part = New("Part",LeftArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 1),CFrame = CFrame.new(4.9000001, 3.90006065, -4.50000048, -1, 0, 0, 0, 1.00001287, 0, 0, 0, -1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),C1 = CFrame.new(-0.400000095, 0.899991989, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
Part = New("Part",LeftArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 0.200000003),CFrame = CFrame.new(4.10000086, 2.70005608, -4.50000048, 0, 0, -1, 0, 1.00001287, 0, 1.00001287, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),C1 = CFrame.new(0.399999142, -0.29999733, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
Part = New("Part",LeftArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 1),CFrame = CFrame.new(4.5, 2.50004888, -4.50000048, -1, 0, 0, 0, 1.00001287, 0, 0, 0, -1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),C1 = CFrame.new(0, -0.500001907, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
Part = New("Part",LeftArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.400000006, 1),CFrame = CFrame.new(4.30000114, 4.00006056, -4.50000048, -1, 0, 0, 0, 1.00001287, 0, 0, 0, -1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),C1 = CFrame.new(0.199999094, 0.999990463, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
Part = New("Part",LeftArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 0.200000003),CFrame = CFrame.new(4.9000001, 4.10006046, -4.50000048, 0, 0, -1, 0, 1.00001287, 0, 1.00001287, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),C1 = CFrame.new(-0.400000095, 1.09998894, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
Part = New("Part",LeftArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.400000006, 0.400000006),CFrame = CFrame.new(3.60000014, 4.00006056, -4.50000048, 0, 0, 1, 0, 1.00001287, 0, -1.00001287, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),C1 = CFrame.new(0.899999857, 0.999990463, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
EnamatePart = New("Part",LeftArm,"EnamatePart",{BrickColor = BrickColor.new("Institutional white"),Material = Enum.Material.SmoothPlastic,Transparency = 1,Transparency = 1,Size = Vector3.new(1, 0.400000036, 1),CFrame = CFrame.new(4.5, 2.00003481, -4.50000906, 1, 0, 0, 0, 1.00001287, 0, 0, 0, 1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.972549, 0.972549, 0.972549),})
Weld = New("ManualWeld",EnamatePart,"Weld",{Part0 = EnamatePart,Part1 = MainPart,C1 = CFrame.new(-2.38418579e-007, -1.00000954, 8.58306885e-006, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
Part = New("Part",LeftArm,"Part",{BrickColor = BrickColor.new("Fog"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(1, 0.400000036, 1),CFrame = CFrame.new(4.49999952, 2.20003057, -4.50001335, 1, 0, 0, 0, 1.00002146, 0, 0, 0, 1.00002146),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.780392, 0.831373, 0.894118),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000429, 0, 0, 0, 1.00000429),C1 = CFrame.new(4.76837158e-007, -0.800016403, 1.28746033e-005, -1, 0, 0, 0, 1.00000429, 0, 0, 0, -1.00000429),})
LeftLeg = New("Model",chara,"LeftLeg",{})
MainPart = New("Part",LeftLeg,"MainPart",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(1, 2.00000024, 1),CFrame = CFrame.new(5.5, 1.00003695, -4.5, -1, 0, 0, 0, 1.00000501, 0, 0, 0, -1.00000501),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",MainPart,"Weld",{Part0 = MainPart,Part1 = chara["Left Leg"],C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1.00000572, 0, 0, 0, -1.00000572),C1 = CFrame.new(0, -1.90734863e-006, 1.09672546e-005, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),})
Part = New("Part",LeftLeg,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 1),CFrame = CFrame.new(5.5, 0.500034451, -4.5, -1, 0, 0, 0, 1.00000501, 0, 0, 0, -1.00000501),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),C1 = CFrame.new(0, -0.5, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
Part = New("Part",LeftLeg,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 0.200000003),CFrame = CFrame.new(5.10000229, 0.700036228, -4.5, 0, 0, -1, 0, 1.00000501, 0, 1.00000501, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),C1 = CFrame.new(0.39999795, -0.299999237, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),})
Part = New("Part",LeftLeg,"Part",{BrickColor = BrickColor.new("Fog"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(1, 0.400000036, 1),CFrame = CFrame.new(5.5, 0.199991405, -4.50000048, 1, 0, 0, 0, 1.00001073, 0, 0, 0, 1.00001073),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.780392, 0.831373, 0.894118),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(0, -0.800041556, 4.76837158e-007, -1, 0, 0, 0, 1.00000572, 0, 0, 0, -1.00000572),})
Chest = New("Model",chara,"Chest",{})
MainPart = New("Part",Chest,"MainPart",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(2, 2.00000024, 1),CFrame = CFrame.new(6, 3.00006342, -4.50004101, 1, 0, 0, 0, 1.00001383, 5.96046448e-008, 0, -5.96046448e-008, 1.00001383),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",MainPart,"Weld",{Part0 = MainPart,Part1 = chara.Torso,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),C1 = CFrame.new(0, 1.28746033e-005, -2.43186951e-005, 1, 0, 0, 0, 1.00000715, -1.19209332e-007, 0, 1.19209332e-007, 1.00000715),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.600000024, 0.399999976, 0.200000003),CFrame = CFrame.new(6, 2.16866231, -2.16859388, 5.96039591e-008, -1, 0, 0.707123756, 4.21473736e-008, 0.707122982, -0.707122982, -4.21473274e-008, 0.707123756),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 5.96039591e-008, 0.707110584, -0.707109809, -1, 4.21465884e-008, -4.21465423e-008, 0, 0.707109809, 0.707110584),C1 = CFrame.new(0, -0.831389666, 2.33141494, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(2, 0.200000003, 1),CFrame = CFrame.new(6, 2.10003901, -4.50004339, 1, 0, 0, 0, 1.00002372, 5.96052345e-008, 0, -5.96052345e-008, 1.00002372),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000513, -5.96046661e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(0, -0.900012016, -2.38418579e-006, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(5.69999981, 3.70007658, -4.90005064, 0, 0, 1, 5.96052345e-008, -1.00002372, 0, 1.00002372, 5.96052345e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 5.96046661e-008, 1.00000513, 0, -1.00000513, 5.96046661e-008, 1, 0, 0),C1 = CFrame.new(-0.300000191, 0.700003624, -0.40000391, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.600000024),CFrame = CFrame.new(6.5, 3.90008974, -4.50004339, 1, 0, 0, 0, 1.00002372, 5.96052345e-008, 0, -5.96052345e-008, 1.00002372),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000513, -5.96046661e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(0.5, 0.900013924, -2.38418579e-006, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(5.69999981, 3.90008211, -4.90005064, 0, 0, -1, 5.96052345e-008, 1.00002372, 0, 1.00002372, -5.96052345e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 5.96046661e-008, 1.00000513, 0, 1.00000513, -5.96046661e-008, -1, 0, 0),C1 = CFrame.new(-0.300000191, 0.900006294, -0.40000391, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(5.50000095, 3.90008783, -4.90005064, 0, 0, 1, 5.96052345e-008, -1.00002372, 0, 1.00002372, 5.96052345e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 5.96046661e-008, 1.00000513, 0, -1.00000513, 5.96046661e-008, 1, 0, 0),C1 = CFrame.new(-0.499999046, 0.900012016, -0.40000391, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.399999857, 0.400000006),CFrame = CFrame.new(5.5999999, 2.52222896, -2.52216196, 0, 0, -1, 0.707122922, 0.707123816, 0, 0.707123816, -0.707122922, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0.707109749, 0.707110643, 0, 0.707110643, -0.707109749, -1, 0, 0),C1 = CFrame.new(-0.400000095, -0.477828026, 1.97785163, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 1.80000007, 2),CFrame = CFrame.new(6.00000906, 1.30002105, -3.70002818, -1.59710094e-008, -7.10542736e-015, -1, 0.500011683, 0.866046011, -7.98569921e-009, 0.866046011, -0.500011683, -1.38316274e-008),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1.59710094e-008, 0.500002384, 0.866029918, -7.10542736e-015, 0.866029918, -0.500002384, -1, -7.98555089e-009, -1.38313707e-008),C1 = CFrame.new(9.05990601e-006, -1.70001888, 0.800001621, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.799999893, 1.80000019, 0.200000003),CFrame = CFrame.new(7.30000591, 1.30002677, -4.60004044, 0, -0.500000894, -0.866024911, 5.96052345e-008, 0.866045415, -0.500012755, 1.00002372, -5.16196152e-008, 2.98026706e-008),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 5.96046661e-008, 1.00000513, -0.500000894, 0.866029322, -5.1619125e-008, -0.866024911, -0.500003457, 2.98023863e-008),C1 = CFrame.new(1.30000591, -1.70001316, -0.0999979973, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.799999893, 1.80000019, 0.200000003),CFrame = CFrame.new(4.70000601, 1.30002677, -4.60004044, 0, 0.499999017, -0.866026223, 5.96052345e-008, 0.866046727, 0.500010848, 1.00002372, -5.16196934e-008, -2.98025569e-008),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 5.96046661e-008, 1.00000513, 0.499999017, 0.866030633, -5.16192031e-008, -0.866026223, 0.50000155, -2.98022744e-008),C1 = CFrame.new(-1.29999399, -1.70001316, -0.0999979973, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 4.4000001, 2),CFrame = CFrame.new(6, 2.38080931, -2.38075256, 0, 0, -1, 0.707109869, 0.707110107, 0, 0.707110107, -0.707109869, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0.707109869, 0.707110107, 0, 0.707110107, -0.707109869, -1, 0, 0),C1 = CFrame.new(0, -0.619245529, 2.11925912, 1, 0, 0, 0, 1.00000477, -5.96046448e-008, 0, 5.96046448e-008, 1.00000477),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000006, 1.4000001, 0.200000003),CFrame = CFrame.new(6, 2.90004635, -4.9000144, 1, 0, 0, 0, 1.00001895, 5.96054903e-008, 0, -5.96054903e-008, 1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000513, -5.96046661e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(0, -0.10001564, -0.39996767, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 3.60000014, 0.200000003),CFrame = CFrame.new(6, 0.895817995, -0.895722628, 5.96046412e-008, -0.99999994, 0, 0.707120538, 4.21476685e-008, 0.707119763, -0.707119763, -4.21476223e-008, 0.707120538),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 5.96046412e-008, 0.707110763, -0.707109988, -0.99999994, 4.21470858e-008, -4.21470396e-008, 0, 0.707109988, 0.707110763),C1 = CFrame.new(0, -2.10421658, 3.60426831, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000066, 0.400000006),CFrame = CFrame.new(6.4000001, 2.52221155, -2.52209997, 0, 0, 1, -0.707120538, 0.707119405, 0, -0.707119405, -0.707120538, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -0.707110763, -0.70710963, 0, 0.70710963, -0.707110763, 1, 0, 0),C1 = CFrame.new(0.400000095, -0.47784543, 1.97791362, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 1.60000002, 0.200000003),CFrame = CFrame.new(4.47727203, 1.5081805, -1.50808311, 9.39882394e-009, 0.178885445, -0.983869851, 0.707119942, 0.695714474, 0.126493514, 0.707120419, -0.695713997, -0.126493424),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 9.39882394e-009, 0.707110167, 0.707110643, 0.178885445, 0.695704877, -0.695704401, -0.983869851, 0.12649177, -0.126491681),C1 = CFrame.new(-1.52272797, -1.49186242, 2.99191642, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 1, 0.400000006),CFrame = CFrame.new(6.80000019, 2.73435283, -2.73424101, 1.98723757e-008, 2.98020062e-008, -1, 0.707119763, 0.70712024, 3.51257512e-008, 0.70712024, -0.707119763, -7.02143277e-009),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1.98723757e-008, 0.707109988, 0.707110465, 2.98020062e-008, 0.707110465, -0.707109988, -1, 3.51252645e-008, -7.02133551e-009),C1 = CFrame.new(0.800000191, -0.265707016, 1.76577568, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 1, 0.400000006),CFrame = CFrame.new(5.19999981, 2.73435235, -2.73424149, 0, 0, 1, -0.707120538, 0.707119405, 0, -0.707119405, -0.707120538, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -0.707110763, -0.70710963, 0, 0.70710963, -0.707110763, 1, 0, 0),C1 = CFrame.new(-0.800000191, -0.265707493, 1.7657752, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 1.60000002, 0.200000003),CFrame = CFrame.new(7.52272892, 1.50817478, -1.50807929, -6.16093132e-008, -0.178884313, 0.983862221, -0.707114697, 0.695709288, 0.126492739, -0.707116783, -0.695710361, -0.126493022),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -6.16093132e-008, -0.707104921, -0.707107008, -0.178884313, 0.695699692, -0.695700765, 0.983862221, 0.126490995, -0.126491278),C1 = CFrame.new(1.52272892, -1.49186814, 2.99192023, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000033, 1.60000002, 0.200000003),CFrame = CFrame.new(7.25000572, 1.38660395, -4.90001011, 0.866024911, -0.500000834, 0, 0.500010312, 0.866041303, 5.96054903e-008, -2.98027949e-008, -5.16198391e-008, 1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0.866024911, 0.500003397, -2.98023828e-008, -0.500000834, 0.866029322, -5.1619125e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(1.25000572, -1.61343718, -0.399963856, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(6.0999999, 3.700068, -4.9000144, 0, 0, 1, -5.96054903e-008, 1.00001895, 0, -1.00001895, -5.96054903e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -5.96046661e-008, -1.00000513, 0, 1.00000513, -5.96046661e-008, 1, 0, 0),C1 = CFrame.new(0.0999999046, 0.699994802, -0.39996767, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000033, 1.60000002, 0.200000003),CFrame = CFrame.new(4.75000572, 1.38660395, -4.90001011, -0.866026044, -0.499998868, 0, 0.500008345, -0.866042435, 5.96054903e-008, -2.98026777e-008, 5.16199066e-008, 1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -0.866026044, 0.500001431, -2.98022655e-008, -0.499998868, -0.866030455, 5.16191925e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(-1.24999428, -1.61343718, -0.399963856, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.600000024),CFrame = CFrame.new(5.5, 3.9000864, -4.50000381, 1, 0, 0, 0, 1.00001895, 5.96054903e-008, 0, -5.96054903e-008, 1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000513, -5.96046661e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(-0.5, 0.900010586, 3.71932983e-005, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(6.30000019, 3.70007372, -4.9000144, 0, 0, -1, -5.96054903e-008, -1.00001895, 0, -1.00001895, 5.96054903e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -5.96046661e-008, -1.00000513, 0, -1.00000513, 5.96046661e-008, -1, 0, 0),C1 = CFrame.new(0.300000191, 0.700000525, -0.39996767, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(6.30000019, 3.90008068, -4.9000144, 0, 0, 1, -5.96054903e-008, 1.00001895, 0, -1.00001895, -5.96054903e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -5.96046661e-008, -1.00000513, 0, 1.00000513, -5.96046661e-008, 1, 0, 0),C1 = CFrame.new(0.300000191, 0.900004864, -0.39996767, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1.20000005, 0.200000003, 0.200000003),CFrame = CFrame.new(6, 3.9000864, -4.09998798, 1, 0, 0, 0, 1.00001895, 5.96054903e-008, 0, -5.96054903e-008, 1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000513, -5.96046661e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(0, 0.900010586, 0.400047302, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(5.90000105, 3.70007181, -4.9000144, 0, 0, -1, 5.96054903e-008, 1.00001895, 0, 1.00001895, -5.96054903e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 5.96046661e-008, 1.00000513, 0, 1.00000513, -5.96046661e-008, -1, 0, 0),C1 = CFrame.new(-0.099998951, 0.699998617, -0.39996767, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(6.5, 3.9000864, -4.9000144, 0, 0, -1, -5.96054903e-008, -1.00001895, 0, -1.00001895, 5.96054903e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -5.96046661e-008, -1.00000513, 0, -1.00000513, 5.96046661e-008, -1, 0, 0),C1 = CFrame.new(0.5, 0.900010586, -0.39996767, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 3.5999999),CFrame = CFrame.new(6.00000906, 0.607151985, -3.29996657, 4.27941371e-009, -1.59710094e-008, 1, 0.866041899, 0.500009298, 4.27950164e-009, -0.500009298, 0.866041899, 1.59713149e-008),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 4.27941371e-009, 0.866029978, -0.500002384, -1.59710094e-008, 0.500002384, 0.866029978, 1, 4.27944258e-009, 1.59710947e-008),C1 = CFrame.new(9.05990601e-006, -2.39287829, 1.20005774, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 0.200000003, 2),CFrame = CFrame.new(6, 3.90008068, -3.89998055, 0, 0, -1, 5.96054903e-008, 1.00001895, 0, 1.00001895, -5.96054903e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 5.96046661e-008, 1.00000513, 0, 1.00000513, -5.96046661e-008, -1, 0, 0),C1 = CFrame.new(0, 0.900004864, 0.600052118, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 1.79999995),CFrame = CFrame.new(4.30000687, 0.6071558, -4.09998417, 0.499998927, -0.866026044, 0, 0.866042435, 0.500008404, 5.96054903e-008, -5.16199066e-008, -2.98026812e-008, 1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0.499998927, 0.866030455, -5.16191925e-008, -0.866026044, 0.50000149, -2.98022691e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(-1.69999313, -2.39287448, 0.400051117, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 1.79999995),CFrame = CFrame.new(7.70000648, 0.6071558, -4.09998417, 0.866024911, -0.500000834, 0, 0.500010312, 0.866041303, 5.96054903e-008, -2.98027949e-008, -5.16198391e-008, 1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0.866024911, 0.500003397, -2.98023828e-008, -0.500000834, 0.866029322, -5.1619125e-008, 0, 5.96046661e-008, 1.00000513),C1 = CFrame.new(1.70000648, -2.39287448, 0.400051117, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.600000083, 0.799999952),CFrame = CFrame.new(5.4000001, 2.16864324, -2.16853142, 0, 0, 1, 0.707123935, -0.707122922, 0, 0.707122922, 0.707123935, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0.70711416, 0.707113147, 0, -0.707113147, 0.70711416, 1, 0, 0),C1 = CFrame.new(-0.599999905, -0.831408739, 2.3314774, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("WedgePart",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 4.4000001, 0.800000012),CFrame = CFrame.new(7.4000001, 2.38079023, -2.38069153, 0, 0, -0.99999994, 0.707119942, 0.707120359, 0, 0.707120359, -0.707119942, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0.707110167, 0.707110584, 0, 0.707110584, -0.707110167, -0.99999994, 0, 0),C1 = CFrame.new(1.4000001, -0.619264603, 2.11932015, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("WedgePart",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 1.79999995, 0.800000012),CFrame = CFrame.new(7.40000916, 1.29999423, -3.69998121, 0, 0, -1.00000024, 0.500009537, 0.866042197, 0, 0.866041958, -0.500009656, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0.500002623, 0.866030037, 0, 0.866030276, -0.500002742, -1.00000024, 0, 0),C1 = CFrame.new(1.40000916, -1.7000457, 0.80004859, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("WedgePart",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 1.79999995, 1),CFrame = CFrame.new(4.70000601, 1.29999804, -3.69996977, -0.866025984, 0.499998987, 0, 0.500008464, 0.866042376, -5.96054903e-008, -2.98026848e-008, -5.1619903e-008, -1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -0.866025984, 0.50000155, -2.98022726e-008, 0.499998987, 0.866030395, -5.16191889e-008, 0, -5.96046661e-008, -1.00000513),C1 = CFrame.new(-1.29999399, -1.70004189, 0.800060034, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("WedgePart",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 1.79999995, 1),CFrame = CFrame.new(7.30000591, 1.29999804, -3.69996977, -0.866026938, -0.500001907, 0, -0.500011384, 0.866043329, -5.96054903e-008, 2.98028588e-008, -5.16199599e-008, -1.00001895),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -0.866026938, -0.50000447, 2.98024467e-008, -0.500001907, 0.866031349, -5.16192458e-008, 0, -5.96046661e-008, -1.00000513),C1 = CFrame.new(1.30000591, -1.70004189, 0.800060034, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("WedgePart",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 4.4000001, 0.800000012),CFrame = CFrame.new(4.5999999, 2.38079023, -2.38069153, 0, 0, 1, -0.707119942, 0.707120538, 0, -0.707120538, -0.707119942, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -0.707110167, -0.707110763, 0, 0.707110763, -0.707110167, 1, 0, 0),C1 = CFrame.new(-1.4000001, -0.619264603, 2.11932015, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("WedgePart",Chest,"Part",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 1.79999995, 0.800000012),CFrame = CFrame.new(4.60000896, 1.29999423, -3.69998121, 0, 0, 1, -0.500009418, 0.86604178, 0, -0.86604178, -0.500009418, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -0.500002503, -0.866029859, 0, 0.866029859, -0.500002503, 1, 0, 0),C1 = CFrame.new(-1.39999104, -1.7000457, 0.80004859, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.600000083, 0.800000012),CFrame = CFrame.new(6.5999999, 2.16864347, -2.16853189, 0, 0, -1, -0.707122922, -0.707123935, 0, -0.707123935, 0.707122922, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -0.707113147, -0.70711416, 0, -0.70711416, 0.707113147, -1, 0, 0),C1 = CFrame.new(0.599999905, -0.831408501, 2.33147693, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Fog"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 0.400000006, 0.400000006),CFrame = CFrame.new(6.19999838, 3.80007887, -4.90001774, 0, 0, -1, 0, -1.00002337, 0, -1.00002337, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.780392, 0.831373, 0.894118),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1.00000954, 0, -1.00000954, 0, -1, 0, 0),C1 = CFrame.new(0.199998379, 0.800004244, -0.399971008, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
Part = New("Part",Chest,"Part",{BrickColor = BrickColor.new("Fog"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.200000003, 0.400000006, 0.400000006),CFrame = CFrame.new(5.79999971, 3.80007887, -4.90001774, 0, 0, 1, 5.96051848e-008, -1.00001383, 0, 1.00001383, 5.96051848e-008, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.780392, 0.831373, 0.894118),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 5.96043606e-008, 1, 0, -1, 5.96043606e-008, 1, 0, 0),C1 = CFrame.new(-0.200000286, 0.800004482, -0.399971008, 1, 0, 0, 0, 1, -5.96038205e-008, 0, 5.96038205e-008, 1),})
FakeHead = New("Model",chara,"FakeHead",{})
MainPart = New("Part",FakeHead,"MainPart",{BrickColor = BrickColor.new("Fog"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(2, 1.00000024, 1),CFrame = CFrame.new(6, 4.50005817, -4.5, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.780392, 0.831373, 0.894118),})
Mesh = New("SpecialMesh",MainPart,"Mesh",{Scale = Vector3.new(1.25, 1.25, 1.25),})
Weld = New("ManualWeld",MainPart,"Weld",{Part0 = MainPart,Part1 = chara.Head,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),C1 = CFrame.new(0, 1.90734863e-006, 1.09672546e-005, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),})
Part = New("Part",FakeHead,"Part",{BrickColor = BrickColor.new("Fog"),FormFactor = Enum.FormFactor.Custom,Size = Vector3.new(1.20000005, 1, 0.600000024),CFrame = CFrame.new(6, 5.50007153, -4.69999933, 1, 0, 0, 0, 1.00001001, 0, 0, 0, 1.00001001),CanCollide = false,BottomSurface = Enum.SurfaceType.Smooth,TopSurface = Enum.SurfaceType.Smooth,Color = Color3.new(0.780392, 0.831373, 0.894118),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(0.800000012, 0.800000012, 0.800000012),MeshId = "http://www.roblox.com/asset/?id=101176852   ",MeshType = Enum.MeshType.FileMesh,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(0, 1.00000811, -0.199998379, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),})
Part = New("Part",FakeHead,"Part",{BrickColor = BrickColor.new("Toothpaste"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.400000006),CFrame = CFrame.new(5.89999962, 4.70005989, -5.00000763, -1, 0, 0, 0, 1.00000501, 0, 0, 0, -1.00000501),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0, 1, 1),})
Mesh = New("SpecialMesh",Part,"Mesh",{Offset = Vector3.new(0.0799999982, 0.0299999993, 0.0399999991),Scale = Vector3.new(0.400000006, 1.5, 0.200000003),MeshType = Enum.MeshType.Sphere,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1.00000501, 0, 0, 0, -1.00000501),C1 = CFrame.new(-0.100000381, 0.200000763, -0.500005245, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),})
Part = New("Part",FakeHead,"Part",{BrickColor = BrickColor.new("Toothpaste"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.400000006),CFrame = CFrame.new(6.0999999, 4.70005989, -5.00000763, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0, 1, 1),})
Mesh = New("SpecialMesh",Part,"Mesh",{Offset = Vector3.new(0.0799999982, 0.0299999993, -0.0399999991),Scale = Vector3.new(0.400000006, 1.5, 0.200000003),MeshType = Enum.MeshType.Sphere,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),C1 = CFrame.new(0.0999999046, 0.200000763, -0.500005245, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),})
Part = New("Part",FakeHead,"Part",{BrickColor = BrickColor.new("Medium red"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.400000006, 0.200000003, 0.400000006),CFrame = CFrame.new(6, 4.50007915, -5.00000763, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.854902, 0.52549, 0.478431),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(0.5, 0.5, 0.699999988),MeshType = Enum.MeshType.Sphere,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),C1 = CFrame.new(0, 2.0980835e-005, -0.500005245, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),})
Halberd = New("Model",chara,"Halberd",{})
MainPart = New("Part",Halberd,"MainPart",{BrickColor = BrickColor.new("Pastel light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.400000006, 2, 0.200000003),CFrame = CFrame.new(7.5, 2, -4.80002117, 0, 0, -1, -1, 0, 0, 0, 1, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.686275, 0.866667, 1),})
Mesh = New("CylinderMesh",MainPart,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",MainPart,"Weld",{Part0 = MainPart,Part1 = chara["Right Arm"],C0 = CFrame.new(0, 0, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),C1 = CFrame.new(0, -1.00004983, -0.300009251, 1, 0, 0, 0, 1.00000429, 0, 0, 0, 1.00000429),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.49998522, 2.0999589, -8.10000324, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(-0.0999588966, -3.29998207, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.49998522, 1.8999629, -8.10000324, -1, 0, 0, 0, -1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 1),C1 = CFrame.new(0.100037098, -3.29998207, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 1),CFrame = CFrame.new(7.49998522, 2.0999589, -8.90000439, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(-0.0999588966, -4.09998322, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000006, 0.400000006),CFrame = CFrame.new(7.49998522, 1.79997587, -8.20000648, 1, 0, 0, 0, -1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, -1),C1 = CFrame.new(0.200024068, -3.39998531, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.49998522, 1.8999759, -7.90000439, 1, 0, 0, 0, -1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, -1),C1 = CFrame.new(0.100024104, -3.09998322, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 1),CFrame = CFrame.new(7.49998522, 1.8999629, -8.90000439, -1, 0, 0, 0, -1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 1),C1 = CFrame.new(0.100037098, -4.09998322, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.49998522, 2.09997296, -7.90000439, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(-0.0999729633, -3.09998322, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000006, 0.400000006),CFrame = CFrame.new(7.49998522, 2.19997191, -8.20000648, -1, 0, 0, 0, 1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),C1 = CFrame.new(-0.199971914, -3.39998531, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.49998522, 2.09997296, -7.90000439, -1, 0, 0, 0, 1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),C1 = CFrame.new(-0.0999729633, -3.09998322, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.49998522, 1.8999759, -7.90000439, -1, 0, 0, 0, -1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 1),C1 = CFrame.new(0.100024104, -3.09998322, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.49998522, 1.89998794, -7.70000648, 1, 0, 0, 0, -1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, -1),C1 = CFrame.new(0.100012064, -2.89998531, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.400000006),CFrame = CFrame.new(7.49999475, 1.899966, -1.80001593, 1, 0, 0, 0, -1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, -1),C1 = CFrame.new(0.100033998, 3.00000525, 5.24520874e-006, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.400000006),CFrame = CFrame.new(7.49999475, 2.0999639, -1.80001593, -1, 0, 0, 0, 1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),C1 = CFrame.new(-0.0999639034, 3.00000525, 5.24520874e-006, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 2.0999999, -2.10002279, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(-0.0999999046, 2.69999838, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.49998522, 2.09998703, -7.70000648, -1, 0, 0, 0, 1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, 1, 0, 0, 0, -1),C1 = CFrame.new(-0.0999869108, -2.89998531, 1.47819519e-005, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000006, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 2.00002384, -3.7000227, 0, 0, -1, -1, 0, 0, 0, 1, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("CylinderMesh",Part,"Mesh",{Offset = Vector3.new(0, -0.100000001, 0),Scale = Vector3.new(1.20000005, 0.5, 1.20000005),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),C1 = CFrame.new(-2.39610672e-005, 1.09999847, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.600000024, 1),CFrame = CFrame.new(7.5, 1.10002398, -7.50001907, 1, 0, 0, 0, -1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, -1),C1 = CFrame.new(0.899976015, -2.6999979, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 1.50002396, -7.10002041, 0, 0, -1, 0, 1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0),C1 = CFrame.new(0.499976039, -2.29999924, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000006, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 2, -7.10002041, 0, 0, -1, -1, 0, 0, 0, 1, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("CylinderMesh",Part,"Mesh",{Scale = Vector3.new(1.20000005, 1, 1.20000005),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),C1 = CFrame.new(0, -2.29999924, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000006, 0.200000003),CFrame = CFrame.new(7.5, 1.80002391, -7.10002041, 0, 0, 1, 0, 1, 0, -1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("CylinderMesh",Part,"Mesh",{})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),C1 = CFrame.new(0.199976087, -2.29999924, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 1.50002396, -6.90001869, 1, 0, 0, 0, -1, 0, 0, 0, -1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, -1, 0, 0, 0, -1),C1 = CFrame.new(0.499976039, -2.09999752, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000006, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 2, -2.30002165, 0, 0, -1, -1, 0, 0, 0, 1, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("CylinderMesh",Part,"Mesh",{Offset = Vector3.new(0, 0.100000001, 0),Scale = Vector3.new(1.20000005, 0.5, 1.20000005),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),C1 = CFrame.new(0, 2.49999952, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000006, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 2, -2.30002165, 0, 0, -1, -1, 0, 0, 0, 1, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("CylinderMesh",Part,"Mesh",{})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),C1 = CFrame.new(0, 2.49999952, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.400000006),CFrame = CFrame.new(7.5, 1.30002296, -8.20001888, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(0.69997704, -3.39999771, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.600000024),CFrame = CFrame.new(7.5, 1.50002289, -7.50001907, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(0.499977052, -2.6999979, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000036, 1.80000007),CFrame = CFrame.new(7.5, 1.00002289, -8.90001869, -1, 0, 0, 0, -1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 1),C1 = CFrame.new(0.999977052, -4.09999752, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000006, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 2.00000095, -5.9000206, 0, 0, -1, -1, 0, 0, 0, 1, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("CylinderMesh",Part,"Mesh",{Offset = Vector3.new(0, 0.100000001, 0),Scale = Vector3.new(1.20000005, 0.5, 1.20000005),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),C1 = CFrame.new(-9.53674316e-007, -1.09999943, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 1.90000093, -2.10002279, -1, 0, 0, 0, -1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 1),C1 = CFrame.new(0.0999990702, 2.69999838, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000006, 0.200000003, 0.200000003),CFrame = CFrame.new(7.5, 2, -2.30002165, 0, 0, -1, -1, 0, 0, 0, 1, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("CylinderMesh",Part,"Mesh",{Offset = Vector3.new(0, -0.100000001, 0),Scale = Vector3.new(1.20000005, 0.5, 1.20000005),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),C1 = CFrame.new(0, 2.49999952, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Part = New("Part",Halberd,"Part",{BrickColor = BrickColor.new("Pastel Blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(0.400000006, 5.4000001, 0.200000003),CFrame = CFrame.new(7.5, 2, -5.10002041, 0, 0, -1, -1, 0, 0, 0, 1, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.501961, 0.733333, 0.858824),})
Mesh = New("CylinderMesh",Part,"Mesh",{})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),C1 = CFrame.new(0, -0.299999237, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Hitbox = New("Part",Halberd,"Hitbox",{Transparency = 1,Transparency = 1,Size = Vector3.new(0.200000003, 1.60000002, 3.00000024),CFrame = CFrame.new(7.5, 1.60002398, -8.30001926, -1, 0, 0, 0, -1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,})
Weld = New("ManualWeld",Hitbox,"Weld",{Part0 = Hitbox,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, -1, 0, 0, 0, -1, 0, 0, 0, 1),C1 = CFrame.new(0.399976075, -3.49999809, 0, 0, -1, 0, 0, 0, 1, -1, 0, 0),})
Moon = New("Model",chara,"Moon",{})
MoonPart = New("Part",Moon,"MoonPart",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Transparency = 1,Transparency = 1,Size = Vector3.new(3.00000024, 3, 0.200000003),CFrame = CFrame.new(6.10001802, 9.10006809, -4.50000095, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,})
Mesh = New("SpecialMesh",MoonPart,"Mesh",{MeshType = Enum.MeshType.Sphere,Scale = Vector3.new(1.2,1.2,18)})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(4.90001678, 8.30006599, -4.50000191, 0, 0, -1, 0, 1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0),C1 = CFrame.new(-1.20000124, -0.800002098, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000036, 0.400000036),CFrame = CFrame.new(7.20001698, 8.00006676, -4.50000191, 0, 0, -1, 0, -1, 0, -1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, -1, 0, -1, 0, 0),C1 = CFrame.new(1.09999895, -1.10000134, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(4.90001678, 8.10006618, -4.50000191, 0, 0, 1, 0, -1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, -1, 0, 1, 0, 0),C1 = CFrame.new(-1.20000124, -1.00000191, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.800000012, 0.200000003),CFrame = CFrame.new(7.50001717, 8.60006809, -4.50000095, 0, 0, -1, 0, -1, 0, -1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, -1, 0, -1, 0, 0),C1 = CFrame.new(1.39999914, -0.5, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.600000143),CFrame = CFrame.new(6.30001783, 8.10006523, -4.50000191, 0, 0, 1, 0, 1, 0, -1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),C1 = CFrame.new(0.199999809, -1.00000286, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.600000024, 0.400000006),CFrame = CFrame.new(7.40001726, 9.90007114, -4.50000191, 0, 0, -1, 0, 1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0),C1 = CFrame.new(1.29999924, 0.800003052, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000036, 0.200000003),CFrame = CFrame.new(6.90001678, 8.20006371, -4.50000191, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C1 = CFrame.new(0.79999876, -0.900004387, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000155, 0.200000003, 0.200000003),CFrame = CFrame.new(6.00001669, 7.70006275, -4.50000191, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C1 = CFrame.new(-0.100001335, -1.40000534, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.600000262, 0.600000024, 0.200000003),CFrame = CFrame.new(7.30001783, 9.30006981, -4.50000191, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C1 = CFrame.new(1.19999981, 0.200001717, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1.80000019, 0.200000003, 0.200000003),CFrame = CFrame.new(6.10001659, 7.90006399, -4.50000191, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C1 = CFrame.new(-1.43051147e-006, -1.2000041, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000036, 0.600000024),CFrame = CFrame.new(6.90001726, 10.400074, -4.50000191, 0, 0, -1, 0, 1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0),C1 = CFrame.new(0.799999237, 1.30000591, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000063),CFrame = CFrame.new(6.50001717, 10.3000755, -4.50000191, 0, 0, 1, 0, -1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, -1, 0, 1, 0, 0),C1 = CFrame.new(0.399999142, 1.20000744, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.600000024, 0.400000006),CFrame = CFrame.new(6.80001783, 9.90007114, -4.50000191, 0, 0, 1, 0, -1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, -1, 0, 1, 0, 0),C1 = CFrame.new(0.699999809, 0.800003052, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.400000006),CFrame = CFrame.new(5.20001698, 8.10006618, -4.50000095, 0, 0, -1, 0, 1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, 0, -1, 0, 0),C1 = CFrame.new(-0.900001049, -1.00000191, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.400000036, 0.200000003),CFrame = CFrame.new(6.90001678, 8.60006618, -4.50000191, 0, 0, 1, 0, 1, 0, -1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),C1 = CFrame.new(0.79999876, -0.500001907, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.800000012, 0.200000003),CFrame = CFrame.new(6.60001802, 7.70006275, -4.50000095, 0, 1, 0, 0, 0, 1, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0),C1 = CFrame.new(0.5, -1.40000534, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.600000083),CFrame = CFrame.new(6.10001707, 10.5000744, -4.50000191, 0, 0, 1, 0, -1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, -1, 0, 1, 0, 0),C1 = CFrame.new(-9.53674316e-007, 1.40000629, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.600000024),CFrame = CFrame.new(5.50001669, 7.70006514, -4.50000191, 0, 0, 1, 0, -1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, -1, 0, 1, 0, 0),C1 = CFrame.new(-0.600001335, -1.40000296, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(6.50001717, 10.5000744, -4.50000191, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C1 = CFrame.new(0.399999142, 1.40000629, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(6.70001698, 8.30006695, -4.50000191, 0, 0, 1, 0, 1, 0, -1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),C1 = CFrame.new(0.599998951, -0.800001144, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(5.10001659, 7.90006399, -4.50000191, 0, 0, 1, 0, -1, 0, 1, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, -1, 0, 1, 0, 0),C1 = CFrame.new(-1.00000143, -1.2000041, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.600000024, 0.200000003),CFrame = CFrame.new(7.10001707, 9.90007114, -4.50000191, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C1 = CFrame.new(0.999999046, 0.800003052, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.400000215, 0.800000012, 0.200000003),CFrame = CFrame.new(7.20001698, 8.60006618, -4.50000191, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C1 = CFrame.new(1.09999895, -0.500001907, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",Moon,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 0.200000003),CFrame = CFrame.new(6.70001698, 8.10006523, -4.50000191, 1, 0, 0, 0, 1, 0, 0, 0, 1),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MoonPart,C1 = CFrame.new(0.599998951, -1.00000286, -9.53674316e-007, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
RightArm = New("Model",chara,"RightArm",{})
MainPart = New("Part",RightArm,"MainPart",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(1, 2.00000024, 1),CFrame = CFrame.new(7.5, 3.00005794, -4.49999809, 1, 0, 0, 0, 1.00001287, 0, 0, 0, 1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",MainPart,"Weld",{Part0 = MainPart,Part1 = chara["Right Arm"],C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000429, 0, 0, 0, 1.00000429),C1 = CFrame.new(0, 3.81469727e-006, 1.23977661e-005, 1, 0, 0, 0, 1.00000429, 0, 0, 0, 1.00000429),})
Part = New("Part",RightArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 0.200000003),CFrame = CFrame.new(7.9000001, 2.70005298, -4.49999809, 0, 0, 1, 0, 1.00001287, 0, -1.00001287, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),C1 = CFrame.new(0.399999946, -0.300001144, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",RightArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 1),CFrame = CFrame.new(7.5, 2.5000515, -4.49999809, 1, 0, 0, 0, 1.00001287, 0, 0, 0, 1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(-5.96046448e-008, -0.5, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",RightArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.400000006, 1),CFrame = CFrame.new(7.69999981, 4.00007057, -4.49999809, 1, 0, 0, 0, 1.00001287, 0, 0, 0, 1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(0.199999988, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",RightArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.400000006, 0.400000006),CFrame = CFrame.new(8.39999962, 4.00007057, -4.49999809, 0, 0, -1, 0, 1.00001287, 0, 1.00001287, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, 1, 0, 1, -0, -1, 0, 0),C1 = CFrame.new(0.899999976, 1, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",RightArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 0.200000003),CFrame = CFrame.new(7.0999999, 4.10007238, -4.49999809, 0, 0, 1, 0, 1.00001287, 0, -1.00001287, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{MeshType = Enum.MeshType.Wedge,})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),C1 = CFrame.new(-0.400000095, 1.10000038, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",RightArm,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(0.200000003, 0.200000003, 1),CFrame = CFrame.new(7.0999999, 3.90006924, -4.49999809, 1, 0, 0, 0, 1.00001287, 0, 0, 0, 1.00001287),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(-0.400000036, 0.899999619, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",RightArm,"Part",{BrickColor = BrickColor.new("Fog"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(1, 0.400000036, 1),CFrame = CFrame.new(7.5, 2.20003915, -4.50001097, 1, 0, 0, 0, 1.00002146, 0, 0, 0, 1.00002146),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.780392, 0.831373, 0.894118),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000429, 0, 0, 0, 1.00000429),C1 = CFrame.new(0, -0.800008535, -1.28746033e-005, 1, 0, 0, 0, 1.00000429, 0, 0, 0, 1.00000429),})
RightLeg = New("Model",chara,"RightLeg",{})
MainPart = New("Part",RightLeg,"MainPart",{BrickColor = BrickColor.new("Light blue"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(1, 2.00000024, 1),CFrame = CFrame.new(6.5, 1.00003695, -4.5, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.705882, 0.823529, 0.894118),})
Weld = New("ManualWeld",MainPart,"Weld",{Part0 = MainPart,Part1 = chara["Right Leg"],C0 = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1.00000572, 0, 0, 0, 1.00000572),C1 = CFrame.new(0, -1.90734863e-006, 1.09672546e-005, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),})
Part = New("Part",RightLeg,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 0.200000003),CFrame = CFrame.new(6.9000001, 0.700036228, -4.5, 0, 0, 1, 0, 1.00000501, 0, -1.00000501, 0, 0),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("SpecialMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),MeshType = Enum.MeshType.Wedge,})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C0 = CFrame.new(0, 0, 0, 0, 0, -1, 0, 1, 0, 1, 0, 0),C1 = CFrame.new(0.400000095, -0.299999237, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",RightLeg,"Part",{BrickColor = BrickColor.new("Steel blue"),Material = Enum.Material.Neon,Size = Vector3.new(1, 0.200000003, 1),CFrame = CFrame.new(6.5, 0.500034451, -4.5, 1, 0, 0, 0, 1.00000501, 0, 0, 0, 1.00000501),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.321569, 0.486275, 0.682353),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(0, -0.5, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),})
Part = New("Part",RightLeg,"Part",{BrickColor = BrickColor.new("Fog"),Material = Enum.Material.SmoothPlastic,Size = Vector3.new(1, 0.400000036, 1),CFrame = CFrame.new(6.5, 0.199991465, -4.50000048, 1, 0, 0, 0, 1.00001073, 0, 0, 0, 1.00001073),CanCollide = false,BackSurface = Enum.SurfaceType.SmoothNoOutlines,BottomSurface = Enum.SurfaceType.SmoothNoOutlines,FrontSurface = Enum.SurfaceType.SmoothNoOutlines,LeftSurface = Enum.SurfaceType.SmoothNoOutlines,RightSurface = Enum.SurfaceType.SmoothNoOutlines,TopSurface = Enum.SurfaceType.SmoothNoOutlines,Color = Color3.new(0.780392, 0.831373, 0.894118),})
Mesh = New("BlockMesh",Part,"Mesh",{Scale = Vector3.new(1.00999999, 1.00999999, 1.00999999),})
Weld = New("ManualWeld",Part,"Weld",{Part0 = Part,Part1 = MainPart,C1 = CFrame.new(0, -0.800041497, -4.76837158e-007, 1, 0, 0, 0, 1.00000572, 0, 0, 0, 1.00000572),})

lap = LeftArm:GetChildren()
rap = RightArm:GetChildren()
llp = LeftLeg:GetChildren()
rlp = RightLeg:GetChildren()
chp = Chest:GetChildren()
hdp = FakeHead:GetChildren()

ch = chara:GetChildren()
for i = 1, #ch do
if ch[i].ClassName == "Part" then
ch[i].Transparency = 1
if ch[i].Name == "Torso" then
ch[i].roblox.Transparency = 1
end
if ch[i].Name == "Head" then
ch[i].face.Transparency = 1
end
elseif ch[i].ClassName == "Accessory" then
ch[i]:Destroy()
end
end

Moon:MoveTo(chara.Head.Position + Vector3.new(0,5,0))
local bodp = Instance.new("BodyPosition",MoonPart)
bodp.Name = "MoonForce"
bodp.maxForce = Vector3.new(10000,10000,10000)
bodp.Position = chara.Head.Position + Vector3.new(0,5,0)
local gyrp = Instance.new("BodyGyro",MoonPart)
gyrp.Name = "GyroForce"
gyrp.CFrame = chara.HumanoidRootPart.CFrame + chara.HumanoidRootPart.CFrame.lookVector

--Animations--
function LoadAnim(id)
local anim = New("Animation",chara,"Animation",{AnimationId = "rbxassetid://"..id})
local realanim = chara.Humanoid:LoadAnimation(anim)
return realanim
end
HoldA = LoadAnim(69427262)
Swing1A = LoadAnim(186934658)
Swing2A = LoadAnim(94160738)
Swing3A = LoadAnim(186934910)
Swing4A = LoadAnim(74909528)
RaiseA = LoadAnim(83994319)
RiseA = LoadAnim(169638954)
HoldA:Play()

--Sounds--
function LoadSnd(id,loop,vol,pit)
local snd = New("Sound",chara,"Sound",{SoundId = "rbxassetid://"..id,Looped = loop,Volume = vol,Pitch = pit})
return snd
end
Music = LoadSnd(267871756,true,1,1)
HitSnd = LoadSnd(566593606,false,1,1)
ExpSnd = LoadSnd(142070127,false,1,1)
SlashSnd = LoadSnd(536642316,false,1,1)
ChargeSnd = LoadSnd(137463716,false,1,1)
LasSnd = LoadSnd(162246701,false,1,1)
LasLoopSnd = LoadSnd(162246683,true,1,1)
BlastSnd = LoadSnd(200633327,false,1,1)
FlySnd = LoadSnd(169445602,false,1,1)
BExpSnd = LoadSnd(258057783,false,5,.5)
Music:Play()

--Name Tag--
local naeeym = Instance.new("BillboardGui",chara)
naeeym.Size = UDim2.new(0,100,0,40)
naeeym.StudsOffset = Vector3.new(0,2,0)
naeeym.Adornee = chara.Head
local tecks = Instance.new("TextLabel",naeeym)
tecks.BackgroundTransparency = 1
tecks.BorderSizePixel = 0
tecks.Text = "Lunarine the Moon Rabbit"
tecks.Font = "Fantasy"
tecks.FontSize = "Size24"
tecks.TextStrokeTransparency = 0
tecks.TextStrokeColor3 = Color3.new(0,0,0)
tecks.TextColor3 = BrickColor.new("Baby blue").Color
tecks.Size = UDim2.new(1,0,0.5,0)
local htecks = Instance.new("TextLabel",naeeym)
htecks.BackgroundTransparency = 1
htecks.BorderSizePixel = 0
htecks.Text = chara.Humanoid.Health.."/"..chara.Humanoid.MaxHealth
htecks.Font = "Fantasy"
htecks.FontSize = "Size24"
htecks.TextStrokeTransparency = 0
htecks.TextStrokeColor3 = Color3.new(0,0,0)
htecks.TextColor3 = BrickColor.new("Baby blue").Color
htecks.Size = UDim2.new(1,0,0.5,0)
htecks.Position = UDim2.new(0,0,.5,0)

--Enamate--
function Enamate()
local trace = Instance.new("Part",chara)
trace.Size = Vector3.new(1,1,1)
trace.TopSurface = 0
trace.BottomSurface = 0
trace.BrickColor = BrickColor.new("Baby blue")
trace.Material = "Neon"
trace.CanCollide = false
trace.Anchored = true
trace.CFrame = EnamatePart.CFrame * CFrame.fromEulerAnglesXYZ(math.rad(math.random(0,359)),math.rad(math.random(0,359)),math.rad(math.random(0,359)))
local tracedisp = coroutine.wrap(function()
for i = 1, 9 do
wait(.01)
trace.Transparency = trace.Transparency + .1
end
wait(.01)
trace:Destroy()
end)
tracedisp()
end
function Enamate2()
if chara:FindFirstChild("Ring")== nil then
local angl = CFrame.fromEulerAnglesXYZ(math.rad(math.random(0,359)),math.rad(math.random(0,359)),math.rad(math.random(0,359)))
local trace = Instance.new("Part",chara)
trace.Size = Vector3.new(1,1,1)
trace.Name = "Ring"
trace.TopSurface = 0
trace.BottomSurface = 0
trace.BrickColor = BrickColor.new("Baby blue")
trace.Material = "Neon"
trace.CanCollide = false
trace.Anchored = true
trace.CFrame = EnamatePart.CFrame * angl
local tracem = Instance.new("SpecialMesh",trace)
--tracem.MeshId = "rbxassetid://3270017"
tracem.MeshType = "Sphere"
local tracedisp = coroutine.wrap(function()
for i = 1, 4 do
wait(.01)
trace.Transparency = trace.Transparency + .2
trace.CFrame = EnamatePart.CFrame * angl
tracem.Scale = tracem.Scale + Vector3.new(.5,.5,.5)
end
wait(.01)
trace:Destroy()
end)
tracedisp()
end
end

--Play Sound in Part--
function PlaySnd(snd,part)
local sound = snd:Clone()
sound.PlayOnRemove = true
sound.Parent = Part
sound:Destroy()
end

--Moon Energy Absorb--
function EnergyAbsorb(parta)
local dir = game.Lighting:GetMoonDirection()
local pos = parta + (dir*500)
local particle = Instance.new("Part",chara)
particle.Size = Vector3.new(1,1,1)
particle.Position = pos
particle.BrickColor = BrickColor.new("Baby blue")
particle.Material = "Neon"
particle.CanCollide = false
particle.Anchored = true
particle.CFrame = CFrame.new(pos,parta)
local mehs = Instance.new("BlockMesh",particle)
mehs.Scale = Vector3.new(1,1,1000)
disp = coroutine.wrap(function()
for i = 1, 4 do
wait(.01)
local dir = game.Lighting:GetMoonDirection()
local pos = parta + (dir*500)
particle.Position = pos
particle.CFrame = CFrame.new(pos,parta)
particle.Transparency = particle.Transparency + .2
end
wait(.01)
particle:Destroy()
end)
disp()
end

--Moon Aura--
function MoonOn()
MoonPart.Transparency = 1
ChargeSnd:Play()
for i = 1, 4 do
EnergyAbsorb(MoonPart.Position)
wait(.01)
MoonPart.Transparency = MoonPart.Transparency - .1
end
end
function MoonOff()
MoonPart.Transparency = .6
for i = 1, 4 do
wait(.01)
MoonPart.Transparency = MoonPart.Transparency + .1
end
end

--Chat Function--
function chatfunc(text)
chat = coroutine.wrap(function(ttt)
if chara:FindFirstChild("TalkingBillBoard")~= nil then
chara:FindFirstChild("TalkingBillBoard"):destroy()
end
local naeeym2 = Instance.new("BillboardGui",chara)
naeeym2.Size = UDim2.new(0,100,0,40)
naeeym2.StudsOffset = Vector3.new(0,3,0)
naeeym2.Adornee = chara.Head
naeeym2.Name = "TalkingBillBoard"
local tecks2 = Instance.new("TextLabel",naeeym2)
tecks2.BackgroundTransparency = 1
tecks2.BorderSizePixel = 0
tecks2.Text = text
tecks2.Font = "Fantasy"
tecks2.FontSize = "Size24"
tecks2.TextStrokeTransparency = 0
tecks2.TextColor3 = Color3.new(1,1,1)
tecks2.TextStrokeColor3 = Color3.new(0,0,0)
tecks2.Size = UDim2.new(1,0,0.5,0)
wait(1)
for i = 1, 5 do
wait(.01)
tecks2.Position = tecks2.Position - UDim2.new(0,0,.05,0)
tecks2.TextStrokeTransparency = tecks2.TextStrokeTransparency +.2
tecks2.TextTransparency = tecks2.TextTransparency + .2
end
naeeym2:Destroy()
end)
chat(text)
end

--Damage Function--
function dealdmg(dude,damage,env,toim)
hurt = coroutine.wrap(function(dude2,damage2,env2,toim2)
if dude ~= chara and dude:FindFirstChild("IsHit") == nil then
finaldmg = damage + math.random(-env,env)
dude.Humanoid.Health = dude.Humanoid.Health - finaldmg
local vall = Instance.new("ObjectValue",dude)
vall.Name = "IsHit"
debby:AddItem(vall,toim)
local naeeym2 = Instance.new("BillboardGui",dude)
naeeym2.Size = UDim2.new(0,100,0,40)
naeeym2.StudsOffset = Vector3.new(0,3,0)
naeeym2.Adornee = dude.Head
naeeym2.Name = "TalkingBillBoard"
local tecks2 = Instance.new("TextLabel",naeeym2)
tecks2.BackgroundTransparency = 1
tecks2.BorderSizePixel = 0
tecks2.Text = "-"..finaldmg
tecks2.Font = "Fantasy"
tecks2.FontSize = "Size24"
tecks2.TextStrokeTransparency = 0
tecks2.TextColor3 = Color3.new(1,0.6,0)
tecks2.TextStrokeColor3 = Color3.new(0,0,0)
tecks2.Size = UDim2.new(1,0,0.5,0)
for i = 1, 5 do
wait(.1)
tecks2.Position = tecks2.Position - UDim2.new(0,0,.05,0)
tecks2.TextStrokeTransparency = tecks2.TextStrokeTransparency +.2
tecks2.TextTransparency = tecks2.TextTransparency + .2
end
naeeym2:Destroy()
end
end)
hurt(dude,damage,env,toim)
end

--Explode Hitbox--
function ExHitbox(rad,pos,damage,env,toim)
local E = Instance.new("Explosion") 
E.Position = pos
E.Parent = game.Workspace
E.BlastRadius = rad
E.BlastPressure = 0
E.Visible = false
E.Hit:connect(function(hit)
if hit.Parent:FindFirstChild("Humanoid")~=nil then
dealdmg(hit.Parent,damage,env,toim)
end
end)
end

--Blade Touch--
function bladehit(hit)
if bladeactive == true then
if hit.Parent:FindFirstChild("Humanoid") ~= nil then
dealdmg(hit.Parent,12,2,.1)
HitSnd:Play()
end
end
end
Hitbox.Touched:connect(bladehit)

--Moon Star--
function MoonStar()
del = true
RaiseA:Play()
MoonOn()
for i = 1, 3 do
wait(.2)
BlastSnd:Play()
local missile = Instance.new("Part",game.Workspace)
Mouse.TargetFilter = missile
missile.CanCollide = false
missile.Shape = 0
missile.Size = Vector3.new(3,3,3)
missile.Name = "Blast"
missile.BrickColor = BrickColor.new("Baby blue")
missile.Material = "Neon"
missile.BottomSurface = 0
missile.TopSurface = 0
missile.CFrame = MoonPart.CFrame
debby:AddItem(missile,10)
local mehs = Instance.new("SpecialMesh",missile)
mehs.MeshType = "Sphere"
local bodf = Instance.new("BodyForce",missile)
bodf.Force = Vector3.new(0,game.Workspace.Gravity*missile:GetMass(),0)
missile.Velocity = (Mouse.Hit.p - MoonPart.Position).unit*50
missile.Touched:connect(function(hit)
if missile.Anchored == false and hit.Parent ~= chara and hit.Parent.Parent ~= chara and hit.Name ~= "Blast" and hit.Name ~= "Trace" then
missile.Anchored = true
PlaySnd(ExpSnd,missile)
ExHitbox(10,missile.Position,20,2,.5)
missile.Anchored = true
for i = 1, 5 do
wait(.01)
missile.Transparency = missile.Transparency + .2
mehs.Scale = mehs.Scale + Vector3.new(1,1,1)
end
end
end)
tracer = coroutine.wrap(function()
while missile.Anchored == false do
wait(.01)
local trace = coroutine.wrap(function()
local tr = Instance.new("Part",game.Workspace)
tr.Name = "Trace"
tr.Size = Vector3.new(3,3,3)
tr.CanCollide = false
tr.Material = "Neon"
tr.Anchored = true
tr.BrickColor = BrickColor.new("Baby blue")
tr.CFrame = missile.CFrame * CFrame.fromEulerAnglesXYZ(math.rad(math.random(0,359)),math.rad(math.random(0,359)),math.rad(math.random(0,359)))
for i = 1, 9 do
wait(.01)
tr.Transparency = tr.Transparency + .1
end
tr:Destroy()
end)
trace()
end
end)
tracer()
end
wait(.5)
MoonOff()
RaiseA:Stop()
del = false
end

--Moon Beam--
function MoonBeam()
del = true
RaiseA:Play()
MoonOn()
wait(.5)
--local EffectPart = Instance.new("Part",game.Workspace)
--EffectPart.Size = Vector3.new(1,1,1)
--EffectPart.Anchored = true
--EffectPart.Transparency = 1
LasSnd:Play()
LasLoopSnd:Play()
for i = 1,50 do
local P = Instance.new("Part") 
local Place0 = CFrame.new(MoonPart.CFrame.x,MoonPart.CFrame.y,MoonPart.CFrame.z) 
local Place1 = Mouse.Hit
--EffectPart.CFrame = Place1
local trace = coroutine.wrap(function()
local tr = Instance.new("Part",game.Workspace)
tr.Name = "Trace"
Mouse.TargetFilter = tr
tr.Size = Vector3.new(0,0,0)
tr.CanCollide = false
tr.Material = "Neon"
tr.Anchored = true
tr.BrickColor = BrickColor.new("Baby blue")
tr.CFrame = Place1 * CFrame.fromEulerAnglesXYZ(math.rad(math.random(0,359)),math.rad(math.random(0,359)),math.rad(math.random(0,359)))
local trm = Instance.new("BlockMesh",tr)
for i = 1, 4 do
wait(.01)
tr.Transparency = tr.Transparency + .2
trm.Scale = trm.Scale + Vector3.new(10,10,10)
end
tr:Destroy()
end)
trace()
local meshla = Instance.new("BlockMesh", P)
meshla.Scale = Vector3.new(1,1,1)
P.formFactor = 0 
P.Size = Vector3.new(1,1,(Place0.p - Place1.p).magnitude) 
P.Name = "Laser" 
P.CFrame = CFrame.new((Place0.p + Place1.p)/2,Place0.p) 
P.Parent = game.Workspace 
P.BrickColor = BrickColor.new("Institutional white")
P.Material = "Neon"
P.Anchored = true 
P.CanCollide = false 
P.Locked = true 
P.BottomSurface = "Smooth" 
P.TopSurface = "Smooth" 
ExHitbox(10,Place1.p,20,1,.5)
wait(0.01)
P:remove()
end
----
LasLoopSnd:Stop()
--EffectPart:Destroy()
wait(.5)
MoonOff()
RaiseA:Stop()
del = false
end

--Moon Pillars--
function MoonPillars()
del = true
ChargeSnd:Play()
RaiseA:Play()
wait(.5)
local num = 10
for i = 1,5 do
local cpos = chara.HumanoidRootPart.CFrame+(chara.HumanoidRootPart.CFrame.lookVector*num)
wait(.1)
local beam = Instance.new("Part",game.Workspace)
beam.Size = Vector3.new(0,0,0)
beam.CFrame = CFrame.new(cpos.x,cpos.y,cpos.z)
beam.CanCollide = false
beam.Anchored = true
beam.BrickColor = BrickColor.new("Baby blue")
beam.Material = "Neon"
local mehs = Instance.new("CylinderMesh",beam)
mehs.Scale = Vector3.new(1,1000,1)
local trace = Instance.new("Part",game.Workspace)
trace.Size = Vector3.new(0,0,0)
trace.CFrame = CFrame.new(cpos.x,cpos.y,cpos.z)
trace.CanCollide = false
trace.Anchored = true
trace.BrickColor = BrickColor.new("Baby blue")
local tmesh2 = Instance.new("SpecialMesh",trace)
tmesh2.MeshId = "http://www.roblox.com/asset/?id=20329976"
tmesh2.Scale = Vector3.new(1,1,1)
tmesh2.Offset = Vector3.new(0,0,-.125)
PlaySnd(ExpSnd,beam)
EnergyAbsorb(beam.CFrame.p)
ExHitbox(20,beam.Position,25,2,.5)
tracegrow = coroutine.wrap(function()
for i = 1, 9 do
wait(.01)
beam.Transparency = beam.Transparency + .1
mehs.Scale = mehs.Scale + Vector3.new(5,5,5)
trace.Transparency = trace.Transparency + .1
tmesh2.Scale = tmesh2.Scale + Vector3.new(1,1,1)
end
beam:Destroy()
trace:Destroy()
end)
tracegrow()
num = num + 10
end
RaiseA:Stop()
del = false
end

--Cross Explosion--
function CrossExplosion()
del = true
ChargeSnd:Play()
local spellcircle = Instance.new("Part",chara)
spellcircle.Anchored = true
spellcircle.Size = Vector3.new(1,1,1)
spellcircle.CFrame = chara.Torso.CFrame - Vector3.new(0,2.4,0)
spellcircle.Transparency = 1
spellcircle.CanCollide = false
local blkm = Instance.new("BlockMesh",spellcircle)
blkm.Scale = Vector3.new(0,1,0)
local dec = Instance.new("Decal",spellcircle)
dec.Color3 = Color3.new(1/170,1,1)
dec.Texture = "rbxassetid://78036587"
dec.Transparency = 1
dec.Face = "Top"
local ptl = Instance.new("PointLight",spellcircle)
ptl.Range = 0
ptl.Color = Color3.new(1/170,1,1)
local bpos = Instance.new("BodyPosition",chara.Torso)
bpos.Position = chara.Torso.Position + Vector3.new(0,10,0)
bpos.maxForce = Vector3.new(10000,10000,10000)
RiseA:Play()
spellc = coroutine.wrap(function()
while spellcircle ~= nil do
wait(.01)
spellcircle.CFrame = spellcircle.CFrame * CFrame.fromEulerAnglesXYZ(0,math.rad(10),0)
end
end)
spellc()
for i = 1, 10 do
wait(.01)
EnergyAbsorb(spellcircle.Position)
ptl.Range = ptl.Range + 1
dec.Transparency = dec.Transparency - .1
blkm.Scale = blkm.Scale + Vector3.new(3,0,3)
end
wait(2)
local pemit = Instance.new("ParticleEmitter",spellcircle)
pemit.Color = ColorSequence.new(Color3.new(0.5,1,1))
pemit.LightEmission = 1
pemit.Size = NumberSequence.new(10)
pemit.Texture = "rbxasset://textures/particles/smoke_main.dds"
pemit.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0,0),NumberSequenceKeypoint.new(0.9,0),NumberSequenceKeypoint.new(1,1)})
pemit.Lifetime = NumberRange.new(1)
pemit.Rate = 10000
pemit.Speed = NumberRange.new(100)
LasSnd:Play()
LasLoopSnd:Play()
ExHitbox(30,spellcircle.Position,40,10,.5)
local trace = Instance.new("Part",game.Workspace)
trace.Size = Vector3.new(0,0,0)
trace.CFrame = spellcircle.CFrame
trace.CanCollide = false
trace.Anchored = true
trace.BrickColor = BrickColor.new("Medium stone grey")
local tmesh2 = Instance.new("SpecialMesh",trace)
tmesh2.MeshId = "http://www.roblox.com/asset/?id=20329976"
tmesh2.Scale = Vector3.new(5,5,5)
tmesh2.Offset = Vector3.new(0,0,-.125)
tracegrow = coroutine.wrap(function()
for i = 1, 9 do
wait(.01)
trace.Transparency = trace.Transparency + .1
tmesh2.Scale = tmesh2.Scale + Vector3.new(5,5,5)
end
trace:Destroy()
end)
tracegrow()
wait(.5)
local pt1 = Instance.new("Part",chara)
pt1.Size = Vector3.new(0,0,0)
pt1.Anchored = true
pt1.CFrame = spellcircle.CFrame + Vector3.new(0,80,0)
pt1.Transparency = 1
local pemit2 = pemit:clone()
pemit2.Lifetime = NumberRange.new(.3)
pemit2.EmissionDirection = "Left"
pemit2.Parent = pt1
local pemit3 = pemit2:clone()
pemit3.EmissionDirection = "Right"
pemit3.Parent = pt1
wait(.5)
for i = 1, 20 do
ExHitbox(30,spellcircle.Position,40,10,.5)
local trace = Instance.new("Part",game.Workspace)
trace.Size = Vector3.new(0,0,0)
trace.CFrame = spellcircle.CFrame
trace.CanCollide = false
trace.Anchored = true
trace.BrickColor = BrickColor.new("Medium stone grey")
local tmesh2 = Instance.new("SpecialMesh",trace)
tmesh2.MeshId = "http://www.roblox.com/asset/?id=20329976"
tmesh2.Scale = Vector3.new(5,5,5)
tmesh2.Offset = Vector3.new(0,0,-.125)
for i = 1, 9 do
wait(.01)
trace.Transparency = trace.Transparency + .1
tmesh2.Scale = tmesh2.Scale + Vector3.new(5,5,5)
end
trace:Destroy()
end
wait(.5)
LasLoopSnd:Stop()
pemit.Enabled = false
pemit2.Enabled = false
pemit3.Enabled = false
for i = 1, 10 do
wait(.01)
ptl.Range = ptl.Range - 1
dec.Transparency = dec.Transparency + .1
blkm.Scale = blkm.Scale - Vector3.new(3,0,3)
end
wait(.5)
spellcircle:Destroy()
bpos:Destroy()
RiseA:Stop()
del = false
end

--Lunar Destruction--
function LunarDestruction()
del = true
local spellcircle = Instance.new("Part",chara)
spellcircle.Anchored = true
spellcircle.Size = Vector3.new(1,1,1)
spellcircle.CFrame = chara.Torso.CFrame - Vector3.new(0,2.4,0)
spellcircle.Transparency = 1
spellcircle.CanCollide = false
local blkm = Instance.new("BlockMesh",spellcircle)
blkm.Scale = Vector3.new(0,1,0)
local dec = Instance.new("Decal",spellcircle)
dec.Color3 = Color3.new(1/170,1,1)
dec.Texture = "rbxassetid://78036587"
dec.Transparency = 1
dec.Face = "Top"
local ptl = Instance.new("PointLight",spellcircle)
ptl.Range = 0
ptl.Color = Color3.new(1/170,1,1)
local bpos = Instance.new("BodyPosition",chara.Torso)
bpos.Position = chara.Torso.Position + Vector3.new(0,50,0)
bpos.maxForce = Vector3.new(10000,10000,10000)
RiseA:Play()
spellc = coroutine.wrap(function()
while spellcircle ~= nil do
wait(.01)
spellcircle.CFrame = spellcircle.CFrame * CFrame.fromEulerAnglesXYZ(0,math.rad(10),0)
end
end)
spellc()
for i = 1, 10 do
wait(.01)
ptl.Range = ptl.Range + 1
dec.Transparency = dec.Transparency - .1
blkm.Scale = blkm.Scale + Vector3.new(10,0,10)
end
wait(2)
local dir = game.Lighting:GetMoonDirection()
local pos = spellcircle.Position + (dir*1400)
local particle = Instance.new("Part",chara)
particle.Transparency = 1
particle.Size = Vector3.new(1,1,1)
particle.Position = pos
particle.BrickColor = BrickColor.new("Baby blue")
particle.Material = "Neon"
particle.CanCollide = false
particle.Anchored = true
particle.CFrame = CFrame.new(pos,spellcircle.Position)
local mehs = Instance.new("BlockMesh",particle)
mehs.Scale = Vector3.new(50,50,3000)
PlaySnd(ChargeSnd,spellcircle)
local pemit = Instance.new("ParticleEmitter",particle)
pemit.Rate = 10000000
pemit.LightEmission = 1
pemit.Size = NumberSequence.new({NumberSequenceKeypoint.new(0,20),NumberSequenceKeypoint.new(1,0)})
pemit.VelocitySpread = 10000
pemit.Speed = NumberRange.new(200)
wait(1)
LasLoopSnd:Play()
LasSnd:Play()
particle.Transparency = 0
for i = 1, 100 do
ExHitbox(60,spellcircle.Position,50,5,.2)
wait(.01)
local trace = coroutine.wrap(function()
local tr = Instance.new("Part",game.Workspace)
tr.Name = "Trace"
tr.Size = Vector3.new(0,0,0)
tr.CanCollide = false
tr.Material = "Neon"
tr.Anchored = true
tr.BrickColor = BrickColor.new("Baby blue")
tr.CFrame = spellcircle.CFrame * CFrame.fromEulerAnglesXYZ(math.rad(math.random(0,359)),math.rad(math.random(0,359)),math.rad(math.random(0,359)))
local trm = Instance.new("BlockMesh",tr)
for i = 1, 4 do
wait(.01)
tr.Transparency = tr.Transparency + .2
trm.Scale = trm.Scale + Vector3.new(200,200,200)
end
tr:Destroy()
end)
trace()
end
for i = 1, 9 do
particle.Transparency = particle.Transparency + .1
wait(.01)
end
particle:Destroy()
LasLoopSnd:Stop()
for i = 1, 10 do
wait(.01)
ptl.Range = ptl.Range - 1
dec.Transparency = dec.Transparency + .1
blkm.Scale = blkm.Scale - Vector3.new(10,0,10)
end
RiseA:Stop()
bpos:Destroy()
spellcircle:Destroy()
del = false
end

--Astral Collision--
function AstralCollision()
local origpos = chara.Torso.Position
local bpos = Instance.new("BodyPosition",chara.Torso)
bpos.Position = origpos + Vector3.new(0,3000,0)
bpos.maxForce = Vector3.new(99999,99999,99999)
RiseA:Play()
FlySnd:Play()
local trace = Instance.new("Part",game.Workspace)
trace.Size = Vector3.new(0,0,0)
trace.CFrame = chara.HumanoidRootPart.CFrame - Vector3.new(0,2,0)
trace.CanCollide = false
trace.Anchored = true
trace.BrickColor = BrickColor.new("Medium stone grey")
local tmesh2 = Instance.new("SpecialMesh",trace)
tmesh2.MeshId = "http://www.roblox.com/asset/?id=20329976"
tmesh2.Scale = Vector3.new(5,5,5)
tmesh2.Offset = Vector3.new(0,0,-.125)
for i = 1, 9 do
wait(.01)
trace.Transparency = trace.Transparency + .1
tmesh2.Scale = tmesh2.Scale + Vector3.new(5,5,5)
end
trace:Destroy()
wait(5)
local moon = Instance.new("Part",chara)
moon.Shape = 0
moon.Size = Vector3.new(1,1,1)
moon.Material = "Pebble"
moon.Position = origpos + Vector3.new(0,2000,0)
local moonmehs = Instance.new("SpecialMesh",moon)
moonmehs.MeshType = "Sphere"
moonmehs.Scale = Vector3.new(1000,1000,1000)
local moonf = Instance.new("BodyPosition",moon)
moonf.Position = origpos - Vector3.new(0,10,0)
moonf.maxForce = Vector3.new(100,100,100)
moon.Touched:connect(function(hit)
if moon.Anchored == false and hit.Parent ~= chara and hit.Parent.Parent ~= chara then
moon.Anchored = true
PlaySnd(BExpSnd,game.Workspace)
local E = Instance.new("Explosion",game.Workspace)
E.BlastRadius = 99999999999999999
E.BlastPressure = 0
E.Position = origpos
E.Visible = false
E.Hit:connect(function(hit)
if hit.Parent ~= chara and hit.Parent.Parent ~= chara then
hit:BreakJoints()
end
end)
wait(1)
bpos.Position = origpos
for i = 1, 9 do
wait(.1)
moon.Transparency = moon.Transparency + .1
end
wait(.1)
moon:Destroy()
wait(1)
bpos:Destroy()
RiseA:Stop()
end
end)
end

--Keys--
del = false
mus = false
function onKeyDown(key)
if del == false then
if key == "z" then
MoonStar()
elseif key == "x" then
MoonBeam()
elseif key == "c" then
MoonPillars()
elseif key == "v" then
CrossExplosion()
elseif key == "b" then
LunarDestruction()
elseif key == "n" then
AstralCollision()
end
end
if key == "m" then
if mus == true then
Music:Stop()
mus = false
elseif mus == false then
Music:Play()
mus = true
end
end
end

--Click--
combo = 0
function onButton1Down()
if del == false then
if combo == 0 then
del = true
SlashSnd.Pitch = 1
SlashSnd:Play()
Swing1A:Play()
bladeactive = true
wait(.5)
Swing1A:Stop()
bladeactive = false
combo = 1
del = false
elseif combo == 1 then
del = true
SlashSnd.Pitch = 1.1
SlashSnd:Play()
Swing2A:Play()
bladeactive = true
wait(.5)
Swing2A:Stop()
bladeactive = false
combo = 2
del = false
elseif combo == 2 then
del = true
SlashSnd.Pitch = .9
SlashSnd:Play()
Swing3A:Play()
bladeactive = true
wait(.5)
Swing3A:Stop()
bladeactive = false
combo = 3
del = false
elseif combo == 3 then
del = true
ExpSnd:Play()
Swing4A:Play()
ExHitbox(10,chara.Torso.Position + chara.Torso.CFrame.lookVector*10,20,5,.5)
local jtrace = Instance.new("Part",game.Workspace)
jtrace.Size = Vector3.new(1,1,1)
jtrace.Position = chara.Torso.Position + chara.Torso.CFrame.lookVector*10
jtrace.CFrame = chara.Torso.CFrame + chara.Torso.CFrame.lookVector*10
jtrace.Anchored = true
jtrace.CanCollide = false
jtrace.Material = "Neon"
jtrace.BrickColor = BrickColor.new("Baby blue")
jtrace.Transparency = .3
local tmesh = Instance.new("SpecialMesh",jtrace)
tmesh.MeshType = "Sphere"
tmesh.Scale = Vector3.new(3,3,3)
local jtrace2 = Instance.new("Part",game.Workspace)
jtrace2.Size = Vector3.new(0,0,0)
jtrace2.BrickColor = BrickColor.new("Institutional white")
jtrace2.Position = chara.Torso.Position + chara.Torso.CFrame.lookVector*10
jtrace2.CFrame = chara.Torso.CFrame + chara.Torso.CFrame.lookVector*10
jtrace2.Anchored = true
jtrace2.Transparency = .3
local tmesh2 = Instance.new("SpecialMesh",jtrace2)
tmesh2.MeshId = "http://www.roblox.com/asset/?id=1125478"
tmesh2.Scale = Vector3.new(5,0,5)
tracegrow = coroutine.wrap(function()
for i = 1, 7 do
wait(.01)
jtrace.Transparency = jtrace.Transparency + .1
tmesh.Scale = tmesh.Scale + Vector3.new(2,2,2)
jtrace2.Transparency = jtrace2.Transparency + .1
tmesh2.Scale = tmesh2.Scale + Vector3.new(1,.05,1)
end
jtrace:Destroy()
jtrace2:Destroy()
end)
tracegrow()
wait(.5)
Swing4A:Stop()
combo = 0
del = false
end
end
end

--Mouse Functions--
if Mouse then
Mouse.KeyDown:connect(onKeyDown)
Mouse.Button1Down:connect(onButton1Down)
end

--To Night--
loopnight = coroutine.wrap(function()
if chara.Humanoid.Health > 1 then
wait(.1)
game.Lighting.TimeOfDay = "20:00:00"
end
end)
night = coroutine.wrap(function()
game.Lighting.TimeOfDay = "12:00:00"
wait(.1)
game.Lighting.TimeOfDay = "13:00:00"
wait(.1)
game.Lighting.TimeOfDay = "14:00:00"
wait(.1)
game.Lighting.TimeOfDay = "15:00:00"
wait(.1)
game.Lighting.TimeOfDay = "16:00:00"
wait(.1)
game.Lighting.TimeOfDay = "17:00:00"
wait(.1)
game.Lighting.TimeOfDay = "18:00:00"
wait(.1)
game.Lighting.TimeOfDay = "19:00:00"
wait(.1)
game.Lighting.TimeOfDay = "20:00:00"
wait(.1)
loopnight()
end)
night()

--DIE--
chara.Humanoid.Died:connect(function()
origpos = chara.Torso.Position
for i = 1, #lap do
lap[i].Anchored = true
end
for i = 1, #rap do
rap[i].Anchored = true
end
for i = 1, #llp do
llp[i].Anchored = true
end
for i = 1, #rlp do
rlp[i].Anchored = true
end
for i = 1, #chp do
chp[i].Anchored = true
end
for i = 1, #hdp do
hdp[i].Anchored = true
end
for i = 1, #ch do
if ch[i].ClassName == "Part" then
ch[i].Anchored = true
end
end
wait(.01)
game.Lighting.TimeOfDay = "20:00:00"
wait(.01)
game.Lighting.TimeOfDay = "19:00:00"
wait(.01)
game.Lighting.TimeOfDay = "18:00:00"
wait(.01)
game.Lighting.TimeOfDay = "17:00:00"
wait(.01)
game.Lighting.TimeOfDay = "16:00:00"
wait(.01)
game.Lighting.TimeOfDay = "15:00:00"
wait(.01)
game.Lighting.TimeOfDay = "14:00:00"
wait(.01)
game.Lighting.TimeOfDay = "13:00:00"
wait(.01)
game.Lighting.TimeOfDay = "12:00:00"
end)

--Loop Function--
while true do
if chara.Humanoid.Health > 1 then
wait(.1)
Enamate()
Enamate2()
chara.Humanoid.MaxHealth = 9999999999999
chara.Humanoid.Health = chara.Humanoid.Health + 999999999999
htecks.Text = chara.Humanoid.Health.."/"..chara.Humanoid.MaxHealth
bodp.Position = chara.Head.Position + Vector3.new(0,5,0)
gyrp.CFrame = CFrame.new(chara.HumanoidRootPart.Position + (chara.HumanoidRootPart.CFrame.lookVector*5), chara.HumanoidRootPart.Position + (chara.HumanoidRootPart.CFrame.lookVector*10))
gyrp.maxTorque = Vector3.new(9000,9000,9000)
for i = 1, #lap do
lap[i].Anchored = false
end
for i = 1, #rap do
rap[i].Anchored = false
end
for i = 1, #llp do
llp[i].Anchored = false
end
for i = 1, #rlp do
rlp[i].Anchored = false
end
for i = 1, #chp do
chp[i].Anchored = false
end
for i = 1, #hdp do
hdp[i].Anchored = false
end
for i = 1, #ch do
if ch[i].ClassName == "Part" then
ch[i].Anchored = false
end
end
end
end