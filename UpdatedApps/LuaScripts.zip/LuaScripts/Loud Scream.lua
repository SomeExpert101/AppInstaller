Instance.new("Sound").Parent = game.Workspace
game.Workspace.Sound.Name = "Music"
game.Workspace.Music.SoundId = "rbxassetid://1587423574"
game.Workspace.Music.Volume = 999999999
game.Workspace.Music:Play()