gui1=Instance.new("BillboardGui")
gui1.Parent= game.Players.LocalPlayer.Character.Head
gui1.Adornee= game.Players.LocalPlayer.Character.Head
gui1.Size=UDim2.new(12,0,12,0)
gui1.StudsOffset=Vector3.new(0,0.2,0)
gui1.AlwaysOnTop = false
text1=Instance.new("ImageLabel")
text1.Image = "http://www.roblox.com/asset/?id=1683750715" --[[Face Image Source (If you wish to change the face to a different decal put it in there]]
text1.Size=UDim2.new(1,0,1,0)
text1.Position=UDim2.new(0,0,0,0)
text1.BackgroundTransparency = 1
text1.Parent=gui1

local char = game.Players.LocalPlayer.Character
char.Head.Transparency = 1
char['Right Arm'].Transparency = 1
char['Left Arm'].Transparency = 1
char.Torso.Transparency = 1
char['Right Leg'].Transparency = 1
char['Left Leg'].Transparency = 1

Instance.new("Sound").Parent = game.Workspace
game.Workspace.Sound.Name = "Music"
game.Workspace.Music.SoundId = "rbxassetid://1591647762"
game.Workspace.Music.Volume = 999999999
game.Workspace.Music:Play()
