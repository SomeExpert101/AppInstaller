Instance.new("Sound").Parent = game.Workspace
game.Workspace.Sound.Name = "Music"
game.Workspace.Music.SoundId = "rbxassetid://1587423574"
game.Workspace.Music.PlaybackSpeed = 1
game.Workspace.Music.Volume = 999999999
game.Workspace.Music:Play()
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.10
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.20
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.30
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.40
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.50
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.60
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.70
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.80
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 1.90
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 2
wait(0.5)
game.Workspace.Music.PlaybackSpeed = 2.10



local Model = Instance.new("Model",workspace)
local Cloud1 = Instance.new("Part")
local Cloud2 = Instance.new("Part")
local Cloud1Mesh = Instance.new("SpecialMesh")
local Cloud2Mesh = Instance.new("SpecialMesh")
local Sound = Instance.new("Sound",workspace)
local sky = Instance.new("Sky")
NUKE_COLOR = 24 --Only BrickColor codes.
CLOUD_TRANSPARENCY = 0.25

function radiation(hit)
    local h = hit.Parent:findFirstChild("Humanoid")
    local DAMAGE = 10
    if h~=nil then
        h.WalkSpeed = 5
        h.Parent["Right Leg"]:Destroy()
        h.Parent["Left Arm"]:Destroy()
        for i =1,h.MaxHealth do
         h.Health = h.Health - DAMAGE
        wait(1)
        end
    end
end
      function unanchor (m)
    for _,i in pairs (m:GetChildren()) do
        if i:IsA("Part","Model","Union","WedgePart","CornerWedgePart") then
 --           i.Anchored = false
            local Fire = Instance.new("Fire")
            Fire.Parent = i
            Fire.Size = math.random(5,10)
            i.Material = "CorrodedMetal"
            i:BreakJoints()
            i.BrickColor = BrickColor.new(26)
             i.Touched:connect(radiation)

        else
            unanchor(i)
        end
    end
end
unanchor(game.Workspace)

Sound.SoundId = "http://www.roblox.com/asset?id=130768997"
Sound.PlaybackSpeed = 1
Sound.Playing = true
Sound.Volume = 99999999

Model.Name = "Mushroom Cloud"
Cloud1.Parent = Model
Cloud1.Anchored = true
Cloud1.CanCollide = false
Cloud1.Locked = true
Cloud1Mesh.Parent = Cloud1
Cloud1Mesh.MeshType = "FileMesh"
Cloud1Mesh.MeshId = "http://www.roblox.com/asset/?id=1095708"
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(95,300,195) --1999
Cloud2.Parent = Model
Cloud2.Anchored = true
Cloud2.CanCollide = false
Cloud2.Locked = true
Cloud2.Position = Cloud2.Position + Vector3.new(0,587,0)
Cloud2Mesh.Parent = Cloud2
Cloud2Mesh.MeshType = "FileMesh"
Cloud2Mesh.MeshId = "http://www.roblox.com/asset/?id=1095708"
Cloud2Mesh.Scale = Cloud2Mesh.Scale + Vector3.new(399,399,649)
Cloud1.Transparency = CLOUD_TRANSPARENCY
Cloud2.Transparency = CLOUD_TRANSPARENCY
Cloud1.BrickColor = BrickColor.new(NUKE_COLOR)
Cloud2.BrickColor = BrickColor.new(NUKE_COLOR)
   sky.Parent = game.Lighting
   sky.Name = "NukeSky"
   sky.CelestialBodiesShown = true
   sky.SkyboxBk = "http://www.roblox.com/asset/?version=1&id=1012890"
   sky.SkyboxDn = "http://www.roblox.com/asset/?version=1&id=1012891"
   sky.SkyboxFt = "http://www.roblox.com/asset/?version=1&id=1012887"
   sky.SkyboxLf = "http://www.roblox.com/asset/?version=1&id=1012889"
   sky.SkyboxRt = "http://www.roblox.com/asset/?version=1&id=1012888"
   sky.SkyboxUp = "http://www.roblox.com/asset/?version=1&id=1014449"
  explosion = Instance.new("Explosion")
   explosion.Parent = game.Workspace
   explosion.BlastRadius = 9999999999999
   explosion.BlastPressure = 10000000
game.Lighting.Brightness = 999
game.Lighting.OutdoorAmbient = Color3.new(1,0,0)
wait (1) --Fireball
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,200,0) --200
wait (0.25)
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,200,0) --400
wait (0.25)
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,200,0) --600
wait (0.25)
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,200,0) --800
wait (0.25)
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,200,0) --1000
wait (0.25)
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,200,0) --1200
wait (0.25)
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,200,0) --1400
wait (0.25)
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,200,0) --1600
wait (0.25)
Cloud1Mesh.Scale = Cloud1Mesh.Scale + Vector3.new(0,100,0) --1700
wait (30) --End phase of the nuke
game.Lighting.Ambient = Color3.new(0,0,0)
game.Lighting.OutdoorAmbient = Color3.new(127 / 255,127 / 255,127 / 255)
sky:Destroy() 
game.Lighting.Brightness = 1
Cloud1.BrickColor = BrickColor.new(1)
Cloud2.BrickColor = BrickColor.new(1)
Cloud1.Transparency = 0.6
Cloud2.Transparency = 0.6
wait (5)
Cloud1.Transparency = 0.7
Cloud2.Transparency = 0.7
wait (5)
Cloud1.Transparency = 0.8
Cloud2.Transparency = 0.8
wait (5)
Cloud1.Transparency = 0.9
Cloud2.Transparency = 0.9
wait (120)
Cloud1:Destroy()
Cloud2:Destroy()
--BrickColor codes: http://wiki.roblox.com/index.php?title=BrickColor_codes